package com.abul.assignment.employees;

public class manager extends Employee {
	private String department;
	
	public String getdepartment() {
		return department;
	}
	public void setdepartment(String department) {
		this.department=department;
	}
}
