package com.abul.assignment.employees;

public class Employee {
	private String name;
	private int employeeid;
	private double salary;
	
	public String getname() {
		return name;
	}
	public void setname(String name) {
		this.name = name;
	}
	public int employeeid() {
		return employeeid;
	}
	public void setemployeeid(int employeeid) {
		this.employeeid = employeeid;
	}
	public double salary() {
		return salary;
	}
	public void setsalary(double salary) {
		this.salary = salary;
	}

}
