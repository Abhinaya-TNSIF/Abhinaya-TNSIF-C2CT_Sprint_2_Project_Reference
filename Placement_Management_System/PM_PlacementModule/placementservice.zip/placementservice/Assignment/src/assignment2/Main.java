package assignment2;

public class Main {
	public static void main(String[] args) {
		Student st = new Student();
		Comission co = new Comission();
		co.input();
		co.Comission();
		
	}

}
