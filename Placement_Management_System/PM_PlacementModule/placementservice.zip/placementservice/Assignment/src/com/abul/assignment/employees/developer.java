package com.abul.assignment.employees;

public class developer extends Employee {
	private String programminglanguage;
	
	public String getprogramminglanguage() {
		return programminglanguage;
	}
	public void setprogramminglanguage(String programminglanguage) {
		this.programminglanguage=programminglanguage;
	}
	

}
