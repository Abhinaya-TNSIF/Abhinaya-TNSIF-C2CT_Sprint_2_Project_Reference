package assignment2;

public class Student {
	public Student() {
		System.out.println("Student Object is Created");
	}

}
